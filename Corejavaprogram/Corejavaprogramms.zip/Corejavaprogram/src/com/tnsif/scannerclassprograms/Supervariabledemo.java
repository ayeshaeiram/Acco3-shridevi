package com.tnsif.scannerclassprograms;
// demo for super variable

class Company{
	String name="hidzz";
}

class Trainer extends Employee{
	String name="nezz";

void display() {
	System.out.println("child name :"+name);
	System.out.println("parent name :"+super.name);
}
}
public class Supervariabledemo {
public static void main(String[] args) {
	Trainer t=new Trainer();
	t.display();
}
}
