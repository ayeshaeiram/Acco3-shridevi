
package com.tnsif.interfacedemo;

public class LGTTV {

	public LGTTV() {
		// TODO Auto-generated constructor stub
	}

}
