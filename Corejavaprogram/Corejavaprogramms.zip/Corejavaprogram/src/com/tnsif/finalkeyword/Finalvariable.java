package com.tnsif.finalkeyword;

public final class Finalvariable { // cant inherita
	final int a=90;  // final variable u cant change value
	
	final void display() { //you cant override
		System.out.println("welcome")''
	}

	public static void main(String[] args) {
	}

}
